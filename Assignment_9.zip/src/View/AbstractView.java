package View;

import Controller.ControlledShapes;

public class AbstractView implements IView{
  @Override
  public void draw_view() {

  }

  @Override
  public void SetC(ControlledShapes controller) {

  }

  @Override
  public IView getWebView_obj() {
    return null;
  }
}
