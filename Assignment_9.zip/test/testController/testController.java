package testController;

public class testController {
  // test the functions.
  // fist contoller(constructing a model.) -> reads file -> model-> controller->view
// iterator = comparator.
  // implement the interface get the next
  // static, singleton, factory(design pattern) method,solid,adaptor.

}
